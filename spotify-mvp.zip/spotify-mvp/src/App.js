import React, { useState, useRef } from "react";

const songs = [
  {
    id: 1,
    title: "Song One",
    artist: "Artist A",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
  },
  {
    id: 2,
    title: "Song Two",
    artist: "Artist B",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
  },
  {
    id: 3,
    title: "Song Three",
    artist: "Artist C",
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
  },
];

export default function App() {
  const [currentSong, setCurrentSong] = useState(songs[0]);
  const audioRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const playSong = () => {
    audioRef.current.play();
    setIsPlaying(true);
  };

  const pauseSong = () => {
    audioRef.current.pause();
    setIsPlaying(false);
  };

  const togglePlayPause = () => {
    if (isPlaying) {
      pauseSong();
    } else {
      playSong();
    }
  };

  const selectSong = (song) => {
    setCurrentSong(song);
    setIsPlaying(false);
    setTimeout(() => {
      playSong();
    }, 100);
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto", padding: 20, fontFamily: "sans-serif" }}>
      <h2>Simple Spotify MVP</h2>

      <div>
        <h3>Now Playing</h3>
        <p>
          {currentSong.title} — {currentSong.artist}
        </p>
        <audio ref={audioRef} src={currentSong.url} onEnded={() => setIsPlaying(false)} />
        <button onClick={togglePlayPause}>{isPlaying ? "Pause" : "Play"}</button>
      </div>

      <hr />

      <h3>Song List</h3>
      <ul>
        {songs.map((song) => (
          <li
            key={song.id}
            style={{ cursor: "pointer", margin: "10px 0", color: song.id === currentSong.id ? "blue" : "black" }}
            onClick={() => selectSong(song)}
          >
            {song.title} — {song.artist}
          </li>
        ))}
      </ul>
    </div>
  );
}
